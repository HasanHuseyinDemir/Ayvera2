export const summaries=[
    {
        title:"Alarm Sistemlerinin Garantisi Var mı?",
        content: "Tüm ürünlerimiz ve kurulumlarımız 2 yıl garantilidir. Ayrıca isteğe bağlı olarak ek garanti ve bakım paketleri sunuyoruz." 
    },
    {
        title:"Kurulumdan Sonra Teknik Destek Alabilir miyim?",
        content: "Evet, 7/24 teknik destek hattımız ve uzaktan destek imkanımız mevcuttur."
    },
    {
        title:"Fiyat Teklifi Almak için Ne Yapmalıyım?",
        content: "İletişim formumuzu doldurabilir veya doğrudan bizi arayarak ücretsiz keşif ve teklif talebinde bulunabilirsiniz."
    }
]