import{s as se,o as f,p as ve,q as _e,F as N,r as we,c as oe,i as ie,t as je,w as $e,b as j,d as b,l as Ee,j as k,R as ke,Q as Se}from"./q-ZndmIxpF.js";const te={manifestHash:"ov3wo0",injections:[{tag:"link",location:"head",attributes:{rel:"stylesheet",href:"/assets/CAGufnJ3-style.css"}}],bundleGraph:["q-3Cctxsv8.js",76,-9,50,"q-48q37pZ5.js",25,"q-7w4gcHdr.js",25,"q-AqtQ97qe.js",76,"q-B-e2Q5xs.js",33,"q-BaxgHVpd.js",25,"q-BcWM9LB_.js",25,"q-BDb8A3xp.js","q-BEZsbgCH.js",76,"q-BiJkrowG.js",25,"q-Bk83mi4X.js",76,-9,74,"q-Blc6B5Sh.js",76,-10,12,14,-9,52,37,"q-BrZnMBvo.js",17,-9,108,"q-BsofuKOE.js","q-C-3sH5eP.js",76,-9,70,"q-C23kJ6kV.js",76,-9,54,"q-C5eIQfLh.js",76,-9,98,"q-C_e5LQvE.js",33,"q-CCoJ3tjq.js",25,"q-CDEPrNLa.js",76,-9,84,"q-Cjb1rx-V.js",76,"q-CrfyWUTs.js",76,"q-CV8Z3856.js",76,-9,10,"q-CY-NB67l.js",60,-10,104,"q-D07nszt-.js",76,"q-D5LNrGOL.js",76,"q-DH-Im5wn.js",33,"q-dHwleXQA.js",16,"q-DLvt1eBM.js",76,-9,88,"q-DPe_43Tu.js",76,"q-Drx0jxsk.js",76,-9,58,"q-DSYjC8SI.js",25,-9,102,"q-DI_mMF3V.js",17,54,-10,"q-Egun0uL-.js",33,"q-loXDNgWp.js",33,"q-MvD3Ymmh.js",25,"q-OUn-jpVp.js",25,"q-u5-5tV3F.js",4,-9,19,"q-zTrX4v6V.js",76,"CNynoMyr3bI",-9,104,"JpT0kys0hb0",-9,17,"VnPk4xCzPsM",-9,104,"8vn0xwKh6TE",-8,14,"j9ZQ0CoJZic",-8,60,"VCnbKExh2YY",-8,82,"GmUe00xZCIg",-9,104,"GyuB2JAa19k",-8,66,"MmfgtHHqSIA",-9,17,"kO1kBtEqBFE",-8,12,"1SzTrAwzh9c",-7,108,"2cT9asXmhtE",-7,25,"3s5iIN7opGw",-7,58,"8XFaCGmjtLk",-7,96,"8rGzDZJZteQ",-9,17,"DlxIcTkOAXU",-7,19,"EabdJTaXZYg",-8,66,"HbPYgs0eS58",-7,52,"JnEl0iLQcxY",-7,98,"K6j7iA1H00Y",-9,104,"KXxAmEFbOf4",-7,84,"Kwrwzg5156k",-7,54,"PWJJqZlnULA",-8,60,"PzuAiRCdui8",-8,14,"ROS3Xfbsukw",-7,10,"V1KDrfi8ILE",-7,76,"XSE0E99MgK8",-7,88,"ZMGY9TholNE",-7,6,"eRYm4bzoQ3o",-7,102,"eWGNd89SYEg",-7,33,"mWrRS0jZTJQ",-7,92,"qhYkei8HFTM",-7,74,"vnZGFShO9FY",-7,50,"yA9PzPNgB0g",-7,4,"yXpYjIg1rZI",-7,70,"yqoW7nFdDn8",-8,12,"GoHK0p7wFzA",-8,60,"oCweshPaqgc",-8,14,"IzV0xhTf5mg",-6,37,"M4zWY0SFoho",-6,72,"e0v60xH1E0g",-6,8,"hQsHMdvOR0k",-6,100,"0A6PMSkn0RA",-8,14,"8sYNI9VQFoc",-7,25,"8ycqSJeIRkM",-8,12,"RTz9wro05eE",-7,76,"UspEDphFPGw",-7,25,"VJNC700mp3I",-7,6,"WLk7GlwjRAY",-9,17,"cFiszp5qkUg",-8,60,"cUH03zRtamA",-8,14,"nsi5CbMxz8M",-9,17,"y14LR3aik8k",-8,12,"content/cozumler/",-5,38,42,"content/hakkimizda/",-5,38,"content/hizmetler/",-5,0,38,"content/iletisim/",-5,21,38,"content/kurumsal/",-7,96,-5,38,"content/projeler/",-5,38,46,"content/uygulama-alanlari/",-5,38,62],mapping:{s_CNynoMyr3bI:"q-u5-5tV3F.js",s_JpT0kys0hb0:"q-BEZsbgCH.js",s_VnPk4xCzPsM:"q-u5-5tV3F.js",s_8vn0xwKh6TE:"q-BcWM9LB_.js",s_j9ZQ0CoJZic:"q-CrfyWUTs.js",s_VCnbKExh2YY:"q-DPe_43Tu.js",s_GmUe00xZCIg:"q-u5-5tV3F.js",s_GyuB2JAa19k:"q-CY-NB67l.js",s_MmfgtHHqSIA:"q-BEZsbgCH.js",s_kO1kBtEqBFE:"q-BaxgHVpd.js",s_1SzTrAwzh9c:"q-zTrX4v6V.js",s_2cT9asXmhtE:"q-Blc6B5Sh.js",s_3s5iIN7opGw:"q-Cjb1rx-V.js",s_8XFaCGmjtLk:"q-Egun0uL-.js",s_8rGzDZJZteQ:"q-BEZsbgCH.js",s_DlxIcTkOAXU:"q-BiJkrowG.js",s_EabdJTaXZYg:"q-CY-NB67l.js",s_HbPYgs0eS58:"q-CCoJ3tjq.js",s_JnEl0iLQcxY:"q-loXDNgWp.js",s_K6j7iA1H00Y:"q-u5-5tV3F.js",s_KXxAmEFbOf4:"q-Drx0jxsk.js",s_Kwrwzg5156k:"q-CDEPrNLa.js",s_PWJJqZlnULA:"q-CrfyWUTs.js",s_PzuAiRCdui8:"q-BcWM9LB_.js",s_ROS3Xfbsukw:"q-B-e2Q5xs.js",s_V1KDrfi8ILE:"q-dHwleXQA.js",s_XSE0E99MgK8:"q-DSYjC8SI.js",s_ZMGY9TholNE:"q-7w4gcHdr.js",s_eRYm4bzoQ3o:"q-OUn-jpVp.js",s_eWGNd89SYEg:"q-BrZnMBvo.js",s_mWrRS0jZTJQ:"q-DI_mMF3V.js",s_qhYkei8HFTM:"q-DH-Im5wn.js",s_vnZGFShO9FY:"q-C_e5LQvE.js",s_yA9PzPNgB0g:"q-48q37pZ5.js",s_yXpYjIg1rZI:"q-D07nszt-.js",s_yqoW7nFdDn8:"q-BaxgHVpd.js",s_GoHK0p7wFzA:"q-CrfyWUTs.js",s_oCweshPaqgc:"q-BcWM9LB_.js",s_IzV0xhTf5mg:"q-BsofuKOE.js",s_M4zWY0SFoho:"q-D5LNrGOL.js",s_e0v60xH1E0g:"q-AqtQ97qe.js",s_hQsHMdvOR0k:"q-MvD3Ymmh.js",s_0A6PMSkn0RA:"q-BcWM9LB_.js",s_8sYNI9VQFoc:"q-Blc6B5Sh.js",s_8ycqSJeIRkM:"q-BaxgHVpd.js",s_RTz9wro05eE:"q-dHwleXQA.js",s_UspEDphFPGw:"q-Blc6B5Sh.js",s_VJNC700mp3I:"q-7w4gcHdr.js",s_WLk7GlwjRAY:"q-BEZsbgCH.js",s_cFiszp5qkUg:"q-CrfyWUTs.js",s_cUH03zRtamA:"q-BcWM9LB_.js",s_nsi5CbMxz8M:"q-BEZsbgCH.js",s_y14LR3aik8k:"q-BaxgHVpd.js"},preloader:"q-BDb8A3xp.js",core:"q-dHwleXQA.js"};/**
 * @license
 * @builder.io/qwik/server 1.14.1
 * Copyright Builder.io, Inc. All Rights Reserved.
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/QwikDev/qwik/blob/main/LICENSE
 */var Pe=(t=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(t,{get:(e,n)=>(typeof require<"u"?require:e)[n]}):t)(function(t){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+t+'" is not supported')}),Ce="<sync>";function ae(t,e){const n=e==null?void 0:e.mapper,r=t.symbolMapper?t.symbolMapper:(s,i,a)=>{var l;if(n){const c=S(s),u=n[c];if(!u){if(c===Ce)return[c,""];if((l=globalThis.__qwik_reg_symbols)==null?void 0:l.has(c))return[s,"_"];if(a)return[s,`${a}?qrl=${s}`];console.error("Cannot resolve symbol",s,"in",n,a)}return u}};return{isServer:!0,async importSymbol(s,i,a){var h;const l=S(a),c=(h=globalThis.__qwik_reg_symbols)==null?void 0:h.get(l);if(c)return c;let u=String(i);u.endsWith(".js")||(u+=".js");const p=Pe(u);if(!(a in p))throw new Error(`Q-ERROR: missing symbol '${a}' in module '${u}'.`);return p[a]},raf:()=>(console.error("server can not rerender"),Promise.resolve()),nextTick:s=>new Promise(i=>{setTimeout(()=>{i(s())})}),chunkForSymbol(s,i,a){return r(s,n,a)}}}async function Be(t,e){const n=ae(t,e);se(n)}var S=t=>{const e=t.lastIndexOf("_");return e>-1?t.slice(e+1):t},Ae="q:instance",P={$DEBUG$:!1,$invPreloadProbability$:.65},xe=Date.now(),Le=/\.[mc]?js$/,le=0,Ie=1,Te=2,De=3,L,I,Ne=(t,e)=>({$name$:t,$state$:Le.test(t)?le:De,$deps$:ue?e==null?void 0:e.map(n=>({...n,$factor$:1})):e,$inverseProbability$:1,$createdTs$:Date.now(),$waitedMs$:0,$loadedMs$:0}),He=t=>{const e=new Map;let n=0;for(;n<t.length;){const r=t[n++],o=[];let s,i=1;for(;s=t[n],typeof s=="number";)s<0?i=-s/10:o.push({$name$:t[s],$importProbability$:i,$factor$:1}),n++;e.set(r,o)}return e},ce=t=>{let e=T.get(t);if(!e){let n;if(I){if(n=I.get(t),!n)return;n.length||(n=void 0)}e=Ne(t,n),T.set(t,e)}return e},Oe=(t,e)=>{e&&("debug"in e&&(P.$DEBUG$=!!e.debug),typeof e.preloadProbability=="number"&&(P.$invPreloadProbability$=1-e.preloadProbability)),!(L!=null||!t)&&(L="",I=He(t))},T=new Map,ue,C,de=0,$=[],Re=(...t)=>{console.log(`Preloader ${Date.now()-xe}ms ${de}/${$.length} queued>`,...t)},Fe=()=>{T.clear(),C=!1,ue=!0,de=0,$.length=0},Qe=()=>{C&&($.sort((t,e)=>t.$inverseProbability$-e.$inverseProbability$),C=!1)},ze=()=>{Qe();let t=.4;const e=[];for(const n of $){const r=Math.round((1-n.$inverseProbability$)*10);r!==t&&(t=r,e.push(t)),e.push(n.$name$)}return e},me=(t,e,n)=>{if(n!=null&&n.has(t))return;const r=t.$inverseProbability$;if(t.$inverseProbability$=e,!(r-t.$inverseProbability$<.01)&&(L!=null&&t.$state$<Te&&t.$inverseProbability$<P.$invPreloadProbability$&&(t.$state$===le&&(t.$state$=Ie,$.push(t),P.$DEBUG$&&Re(`queued ${Math.round((1-t.$inverseProbability$)*100)}%`,t.$name$)),C=!0),t.$deps$)){n||(n=new Set),n.add(t);const o=1-t.$inverseProbability$;for(const s of t.$deps$){const i=ce(s.$name$);if(i.$inverseProbability$===0)continue;let a;if(s.$importProbability$>.5&&(o===1||o>=.99&&D<100))D++,a=Math.min(.01,1-s.$importProbability$);else{const l=1-s.$importProbability$*o,c=s.$factor$,u=l/c;a=Math.max(.02,i.$inverseProbability$*u),s.$factor$=u}me(i,a,n)}}},ne=(t,e)=>{const n=ce(t);n&&n.$inverseProbability$>e&&me(n,e)},D,Ye=(t,e)=>{if(!(t!=null&&t.length))return;D=0;let n=e?1-e:.4;if(Array.isArray(t))for(let r=t.length-1;r>=0;r--){const o=t[r];typeof o=="number"?n=1-o/10:ne(o,n)}else ne(t,n)};function Je(t){const e=[],n=r=>{if(r)for(const o of r)e.includes(o.url)||(e.push(o.url),o.imports&&n(o.imports))};return n(t),e}var Ve=t=>{var n;const e=we();return(n=t==null?void 0:t.qrls)==null?void 0:n.map(r=>{var a;const o=r.$refSymbol$||r.$symbol$,s=r.$chunk$,i=e.chunkForSymbol(o,s,(a=r.dev)==null?void 0:a.file);return i?i[1]:s}).filter(Boolean)};function Ge(t,e,n){const r=e.prefetchStrategy;if(r===null)return[];if(!(n!=null&&n.manifest.bundleGraph))return Ve(t);if(typeof(r==null?void 0:r.symbolsToPrefetch)=="function")try{const s=r.symbolsToPrefetch({manifest:n.manifest});return Je(s)}catch(s){console.error("getPrefetchUrls, symbolsToPrefetch()",s)}const o=new Set;for(const s of(t==null?void 0:t.qrls)||[]){const i=S(s.$refSymbol$||s.$symbol$);i&&i.length>=10&&o.add(i)}return[...o]}var Ue=(t,e)=>{if(!(e!=null&&e.manifest.bundleGraph))return[...new Set(t)];Fe();let n=.99;for(const r of t.slice(0,15))Ye(r,n),n*=.85;return ze().filter(r=>r!==(e==null?void 0:e.manifest.preloader)&&r!==(e==null?void 0:e.manifest.core))},Ze=(t,e,n,r,o)=>{var i;const s=(i=e==null?void 0:e.manifest)==null?void 0:i.preloader;if(s&&n!==!1){const a=typeof n=="object"?{debug:n.debug,preloadProbability:n.ssrPreloadProbability}:void 0;Oe(e==null?void 0:e.manifest.bundleGraph,a);const l=[];n!=null&&n.debug&&l.push("d:1"),n!=null&&n.maxIdlePreloads&&l.push(`P:${n.maxIdlePreloads}`),n!=null&&n.preloadProbability&&l.push(`Q:${n.preloadProbability}`);const c=l.length?`,{${l.join(",")}}`:"",u=e==null?void 0:e.manifest.manifestHash,p=`let b=fetch("${t}q-bundle-graph-${u}.json");import("${t}${s}").then(({l})=>l(${JSON.stringify(t)},b${c}));`;r.push(f("link",{rel:"modulepreload",href:`${t}${s}`}),f("link",{rel:"preload",href:`${t}q-bundle-graph-${e==null?void 0:e.manifest.manifestHash}.json`,as:"fetch",crossorigin:"anonymous"}),f("script",{type:"module",async:!0,dangerouslySetInnerHTML:p,nonce:o}));const h=e==null?void 0:e.manifest.core;h&&r.push(f("link",{rel:"modulepreload",href:`${t}${h}`}))}},We=(t,e,n,r,o)=>{if(r.length===0||n===!1)return null;const{ssrPreloads:s,ssrPreloadProbability:i}=Ke(typeof n=="boolean"?void 0:n);let a=s;const l=[],c=[],u=e==null?void 0:e.manifest.manifestHash;if(a){const h=Ue(r,e);let v=4;const w=i*10;for(const d of h)if(typeof d=="string"){if(v<w||(c.push(d),--a===0))break}else v=d}const p=u&&(e==null?void 0:e.manifest.preloader);if(p){const v=(c.length?`${JSON.stringify(c)}.map((l,e)=>{e=document.createElement('link');e.rel='modulepreload';e.href=${JSON.stringify(t)}+l;document.head.appendChild(e)});`:"")+`window.addEventListener('load',f=>{f=_=>import("${t}${p}").then(({p})=>p(${JSON.stringify(r)}));try{requestIdleCallback(f,{timeout:2000})}catch(e){setTimeout(f,200)}})`;l.push(f("script",{type:"module","q:type":"preload",async:!0,dangerouslySetInnerHTML:v,nonce:o}))}return l.length>0?f(N,{children:l}):null},Xe=(t,e,n,r,o)=>{var s;if(n.preloader!==!1){const i=Ge(e,n,r);if(i.length>0){const a=We(t,r,n.preloader,i,(s=n.serverData)==null?void 0:s.nonce);a&&o.push(a)}}};function Ke(t){return{...Me,...t}}var Me={ssrPreloads:7,ssrPreloadProbability:.5,debug:!1,maxIdlePreloads:25,preloadProbability:.35},et='(()=>{const t=document,e=window,n=new Set,o=new Set([t]);let r;const s=(t,e)=>Array.from(t.querySelectorAll(e)),a=t=>{const e=[];return o.forEach((n=>e.push(...s(n,t)))),e},i=t=>{w(t),s(t,"[q\\\\:shadowroot]").forEach((t=>{const e=t.shadowRoot;e&&i(e)}))},c=t=>t&&"function"==typeof t.then,l=(t,e,n=e.type)=>{a("[on"+t+"\\\\:"+n+"]").forEach((o=>b(o,t,e,n)))},f=e=>{if(void 0===e._qwikjson_){let n=(e===t.documentElement?t.body:e).lastElementChild;for(;n;){if("SCRIPT"===n.tagName&&"qwik/json"===n.getAttribute("type")){e._qwikjson_=JSON.parse(n.textContent.replace(/\\\\x3C(\\/?script)/gi,"<$1"));break}n=n.previousElementSibling}}},p=(t,e)=>new CustomEvent(t,{detail:e}),b=async(e,n,o,r=o.type)=>{const s="on"+n+":"+r;e.hasAttribute("preventdefault:"+r)&&o.preventDefault(),e.hasAttribute("stoppropagation:"+r)&&o.stopPropagation();const a=e._qc_,i=a&&a.li.filter((t=>t[0]===s));if(i&&i.length>0){for(const t of i){const n=t[1].getFn([e,o],(()=>e.isConnected))(o,e),r=o.cancelBubble;c(n)&&await n,r&&o.stopPropagation()}return}const l=e.getAttribute(s);if(l){const n=e.closest("[q\\\\:container]"),r=n.getAttribute("q:base"),s=n.getAttribute("q:version")||"unknown",a=n.getAttribute("q:manifest-hash")||"dev",i=new URL(r,t.baseURI);for(const p of l.split("\\n")){const l=new URL(p,i),b=l.href,h=l.hash.replace(/^#?([^?[|]*).*$/,"$1")||"default",q=performance.now();let _,d,y;const w=p.startsWith("#"),g={qBase:r,qManifest:a,qVersion:s,href:b,symbol:h,element:e,reqTime:q};if(w){const e=n.getAttribute("q:instance");_=(t["qFuncs_"+e]||[])[Number.parseInt(h)],_||(d="sync",y=Error("sym:"+h))}else{u("qsymbol",g);const t=l.href.split("#")[0];try{const e=import(t);f(n),_=(await e)[h],_||(d="no-symbol",y=Error(`${h} not in ${t}`))}catch(t){d||(d="async"),y=t}}if(!_){u("qerror",{importError:d,error:y,...g}),console.error(y);break}const m=t.__q_context__;if(e.isConnected)try{t.__q_context__=[e,o,l];const n=_(o,e);c(n)&&await n}catch(t){u("qerror",{error:t,...g})}finally{t.__q_context__=m}}}},u=(e,n)=>{t.dispatchEvent(p(e,n))},h=t=>t.replace(/([A-Z])/g,(t=>"-"+t.toLowerCase())),q=async t=>{let e=h(t.type),n=t.target;for(l("-document",t,e);n&&n.getAttribute;){const o=b(n,"",t,e);let r=t.cancelBubble;c(o)&&await o,r=r||t.cancelBubble||n.hasAttribute("stoppropagation:"+t.type),n=t.bubbles&&!0!==r?n.parentElement:null}},_=t=>{l("-window",t,h(t.type))},d=()=>{var s;const c=t.readyState;if(!r&&("interactive"==c||"complete"==c)&&(o.forEach(i),r=1,u("qinit"),(null!=(s=e.requestIdleCallback)?s:e.setTimeout).bind(e)((()=>u("qidle"))),n.has("qvisible"))){const t=a("[on\\\\:qvisible]"),e=new IntersectionObserver((t=>{for(const n of t)n.isIntersecting&&(e.unobserve(n.target),b(n.target,"",p("qvisible",n)))}));t.forEach((t=>e.observe(t)))}},y=(t,e,n,o=!1)=>t.addEventListener(e,n,{capture:o,passive:!1}),w=(...t)=>{for(const r of t)"string"==typeof r?n.has(r)||(o.forEach((t=>y(t,r,q,!0))),y(e,r,_,!0),n.add(r)):o.has(r)||(n.forEach((t=>y(r,t,q,!0))),o.add(r))};if(!("__q_context__"in t)){t.__q_context__=0;const r=e.qwikevents;Array.isArray(r)&&w(...r),e.qwikevents={events:n,roots:o,push:w},y(t,"readystatechange",d),d()}})()',tt=`(() => {
  const doc = document;
  const win = window;
  const events = /* @__PURE__ */ new Set();
  const roots = /* @__PURE__ */ new Set([doc]);
  let hasInitialized;
  const nativeQuerySelectorAll = (root, selector) => Array.from(root.querySelectorAll(selector));
  const querySelectorAll = (query) => {
    const elements = [];
    roots.forEach((root) => elements.push(...nativeQuerySelectorAll(root, query)));
    return elements;
  };
  const findShadowRoots = (fragment) => {
    processEventOrNode(fragment);
    nativeQuerySelectorAll(fragment, "[q\\\\:shadowroot]").forEach((parent) => {
      const shadowRoot = parent.shadowRoot;
      shadowRoot && findShadowRoots(shadowRoot);
    });
  };
  const isPromise = (promise) => promise && typeof promise.then === "function";
  const broadcast = (infix, ev, type = ev.type) => {
    querySelectorAll("[on" + infix + "\\\\:" + type + "]").forEach(
      (el) => dispatch(el, infix, ev, type)
    );
  };
  const resolveContainer = (containerEl) => {
    if (containerEl._qwikjson_ === void 0) {
      const parentJSON = containerEl === doc.documentElement ? doc.body : containerEl;
      let script = parentJSON.lastElementChild;
      while (script) {
        if (script.tagName === "SCRIPT" && script.getAttribute("type") === "qwik/json") {
          containerEl._qwikjson_ = JSON.parse(
            script.textContent.replace(/\\\\x3C(\\/?script)/gi, "<$1")
          );
          break;
        }
        script = script.previousElementSibling;
      }
    }
  };
  const createEvent = (eventName, detail) => new CustomEvent(eventName, {
    detail
  });
  const dispatch = async (element, onPrefix, ev, eventName = ev.type) => {
    const attrName = "on" + onPrefix + ":" + eventName;
    if (element.hasAttribute("preventdefault:" + eventName)) {
      ev.preventDefault();
    }
    if (element.hasAttribute("stoppropagation:" + eventName)) {
      ev.stopPropagation();
    }
    const ctx = element._qc_;
    const relevantListeners = ctx && ctx.li.filter((li) => li[0] === attrName);
    if (relevantListeners && relevantListeners.length > 0) {
      for (const listener of relevantListeners) {
        const results = listener[1].getFn([element, ev], () => element.isConnected)(ev, element);
        const cancelBubble = ev.cancelBubble;
        if (isPromise(results)) {
          await results;
        }
        if (cancelBubble) {
          ev.stopPropagation();
        }
      }
      return;
    }
    const attrValue = element.getAttribute(attrName);
    if (attrValue) {
      const container = element.closest("[q\\\\:container]");
      const qBase = container.getAttribute("q:base");
      const qVersion = container.getAttribute("q:version") || "unknown";
      const qManifest = container.getAttribute("q:manifest-hash") || "dev";
      const base = new URL(qBase, doc.baseURI);
      for (const qrl of attrValue.split("\\n")) {
        const url = new URL(qrl, base);
        const href = url.href;
        const symbol = url.hash.replace(/^#?([^?[|]*).*$/, "$1") || "default";
        const reqTime = performance.now();
        let handler;
        let importError;
        let error;
        const isSync = qrl.startsWith("#");
        const eventData = {
          qBase,
          qManifest,
          qVersion,
          href,
          symbol,
          element,
          reqTime
        };
        if (isSync) {
          const hash = container.getAttribute("q:instance");
          handler = (doc["qFuncs_" + hash] || [])[Number.parseInt(symbol)];
          if (!handler) {
            importError = "sync";
            error = new Error("sym:" + symbol);
          }
        } else {
          emitEvent("qsymbol", eventData);
          const uri = url.href.split("#")[0];
          try {
            const module = import(
                            uri
            );
            resolveContainer(container);
            handler = (await module)[symbol];
            if (!handler) {
              importError = "no-symbol";
              error = new Error(\`\${symbol} not in \${uri}\`);
            }
          } catch (err) {
            importError || (importError = "async");
            error = err;
          }
        }
        if (!handler) {
          emitEvent("qerror", {
            importError,
            error,
            ...eventData
          });
          console.error(error);
          break;
        }
        const previousCtx = doc.__q_context__;
        if (element.isConnected) {
          try {
            doc.__q_context__ = [element, ev, url];
            const results = handler(ev, element);
            if (isPromise(results)) {
              await results;
            }
          } catch (error2) {
            emitEvent("qerror", { error: error2, ...eventData });
          } finally {
            doc.__q_context__ = previousCtx;
          }
        }
      }
    }
  };
  const emitEvent = (eventName, detail) => {
    doc.dispatchEvent(createEvent(eventName, detail));
  };
  const camelToKebab = (str) => str.replace(/([A-Z])/g, (a) => "-" + a.toLowerCase());
  const processDocumentEvent = async (ev) => {
    let type = camelToKebab(ev.type);
    let element = ev.target;
    broadcast("-document", ev, type);
    while (element && element.getAttribute) {
      const results = dispatch(element, "", ev, type);
      let cancelBubble = ev.cancelBubble;
      if (isPromise(results)) {
        await results;
      }
      cancelBubble = cancelBubble || ev.cancelBubble || element.hasAttribute("stoppropagation:" + ev.type);
      element = ev.bubbles && cancelBubble !== true ? element.parentElement : null;
    }
  };
  const processWindowEvent = (ev) => {
    broadcast("-window", ev, camelToKebab(ev.type));
  };
  const processReadyStateChange = () => {
    var _a;
    const readyState = doc.readyState;
    if (!hasInitialized && (readyState == "interactive" || readyState == "complete")) {
      roots.forEach(findShadowRoots);
      hasInitialized = 1;
      emitEvent("qinit");
      const riC = (_a = win.requestIdleCallback) != null ? _a : win.setTimeout;
      riC.bind(win)(() => emitEvent("qidle"));
      if (events.has("qvisible")) {
        const results = querySelectorAll("[on\\\\:qvisible]");
        const observer = new IntersectionObserver((entries) => {
          for (const entry of entries) {
            if (entry.isIntersecting) {
              observer.unobserve(entry.target);
              dispatch(entry.target, "", createEvent("qvisible", entry));
            }
          }
        });
        results.forEach((el) => observer.observe(el));
      }
    }
  };
  const addEventListener = (el, eventName, handler, capture = false) => {
    return el.addEventListener(eventName, handler, { capture, passive: false });
  };
  const processEventOrNode = (...eventNames) => {
    for (const eventNameOrNode of eventNames) {
      if (typeof eventNameOrNode === "string") {
        if (!events.has(eventNameOrNode)) {
          roots.forEach(
            (root) => addEventListener(root, eventNameOrNode, processDocumentEvent, true)
          );
          addEventListener(win, eventNameOrNode, processWindowEvent, true);
          events.add(eventNameOrNode);
        }
      } else {
        if (!roots.has(eventNameOrNode)) {
          events.forEach(
            (eventName) => addEventListener(eventNameOrNode, eventName, processDocumentEvent, true)
          );
          roots.add(eventNameOrNode);
        }
      }
    }
  };
  if (!("__q_context__" in doc)) {
    doc.__q_context__ = 0;
    const qwikevents = win.qwikevents;
    if (Array.isArray(qwikevents)) {
      processEventOrNode(...qwikevents);
    }
    win.qwikevents = {
      events,
      roots,
      push: processEventOrNode
    };
    addEventListener(doc, "readystatechange", processReadyStateChange);
    processReadyStateChange();
  }
})()`;function re(t={}){return t.debug?tt:et}function x(){if(typeof performance>"u")return()=>0;const t=performance.now();return()=>(performance.now()-t)/1e6}function nt(t){let e=t.base;return typeof t.base=="function"&&(e=t.base(t)),typeof e=="string"?(e.endsWith("/")||(e+="/"),e):"/build/"}var rt="<!DOCTYPE html>";async function st(t,e){var Y,J,V,G;let n=e.stream,r=0,o=0,s=0,i=0,a="",l;const c=((Y=e.streaming)==null?void 0:Y.inOrder)??{strategy:"auto",maximunInitialChunk:5e4,maximunChunk:3e4},u=e.containerTagName??"html",p=e.containerAttributes??{},h=n,v=x(),w=nt(e),d=fe(e.manifest);function H(){a&&(h.write(a),a="",r=0,s++,s===1&&(i=v()))}function O(m){const y=m.length;r+=y,o+=y,a+=m}switch(c.strategy){case"disabled":n={write:O};break;case"direct":n=h;break;case"auto":let m=0,y=!1;const U=c.maximunChunk??0,A=c.maximunInitialChunk??0;n={write(_){_==="<!--qkssr-f-->"?y||(y=!0):_==="<!--qkssr-pu-->"?m++:_==="<!--qkssr-po-->"?m--:O(_),m===0&&(y||r>=(s===0?A:U))&&(y=!1,H())}};break}u==="html"?n.write(rt):(n.write("<!--cq-->"),e.qwikLoader?(e.qwikLoader.include===void 0&&(e.qwikLoader.include="never"),e.qwikLoader.position===void 0&&(e.qwikLoader.position="bottom")):e.qwikLoader={include:"never"}),d||console.warn("Missing client manifest, loading symbols in the client might 404. Please ensure the client build has run and generated the manifest for the server build."),await Be(e,d);const R=d==null?void 0:d.manifest.injections,E=R?R.map(m=>f(m.tag,m.attributes??{})):[],B=((J=e.qwikLoader)==null?void 0:J.include)??"auto",pe=((V=e.qwikLoader)==null?void 0:V.position)??"bottom";let F=!1;if(pe==="top"&&B!=="never"){F=!0;const m=re({debug:e.debug});E.push(f("script",{id:"qwikloader",dangerouslySetInnerHTML:m})),E.push(f("script",{dangerouslySetInnerHTML:"window.qwikevents.push('click','input')"}))}Ze(w,d,e.preloader,E,(G=e.serverData)==null?void 0:G.nonce);const he=x(),be=[];let Q=0,z=0;await ve(t,{stream:n,containerTagName:u,containerAttributes:p,serverData:e.serverData,base:w,beforeContent:E,beforeClose:async(m,y,U,A)=>{var X,K,M,ee;Q=he();const _=x();l=await _e(m,y,void 0,A);const q=[];Xe(w,l,e,d,q);const qe=JSON.stringify(l.state,void 0,void 0);if(q.push(f("script",{type:"qwik/json",dangerouslySetInnerHTML:it(qe),nonce:(X=e.serverData)==null?void 0:X.nonce})),l.funcs.length>0){const g=p[Ae];q.push(f("script",{"q:func":"qwik/json",dangerouslySetInnerHTML:ct(g,l.funcs),nonce:(K=e.serverData)==null?void 0:K.nonce}))}const ge=!F&&(!l||l.mode!=="static"),Z=B==="always"||B==="auto"&&ge;if(Z){const g=re({debug:e.debug});q.push(f("script",{id:"qwikloader",dangerouslySetInnerHTML:g,nonce:(M=e.serverData)==null?void 0:M.nonce}))}const W=Array.from(y.$events$,g=>JSON.stringify(g));if(W.length>0){const g=(Z?"window.qwikevents":"(window.qwikevents||=[])")+`.push(${W.join(", ")})`;q.push(f("script",{dangerouslySetInnerHTML:g,nonce:(ee=e.serverData)==null?void 0:ee.nonce}))}return at(be,m),z=_(),f(N,{children:q})},manifestHash:(d==null?void 0:d.manifest.manifestHash)||"dev"+ot()}),u!=="html"&&n.write("<!--/cq-->"),H();const ye=l.resources.some(m=>m._cache!==1/0);return{prefetchResources:void 0,snapshotResult:l,flushes:s,manifest:d==null?void 0:d.manifest,size:o,isStatic:!ye,timing:{render:Q,snapshot:z,firstFlush:i}}}function ot(){return Math.random().toString(36).slice(2)}function fe(t){const e=t?{...te,...t}:te;if(!e||"mapper"in e)return e;if(e.mapping){const n={};return Object.entries(e.mapping).forEach(([r,o])=>{n[S(r)]=[r,o]}),{mapper:n,manifest:e,injections:e.injections||[]}}}var it=t=>t.replace(/<(\/?script)/gi,"\\x3C$1");function at(t,e){var n;for(const r of e){const o=(n=r.$componentQrl$)==null?void 0:n.getSymbol();o&&!t.includes(o)&&t.push(o)}}var lt='document["qFuncs_HASH"]=';function ct(t,e){return lt.replace("HASH",t)+`[${e.join(`,
`)}]`}async function bt(t){const e=ae({},fe(t));se(e)}const ut=()=>{const t=je(),e=$e();return j(N,{children:[b("title",null,null,t.title,1,null),b("link",null,{rel:"canonical",href:Ee(n=>n.url.href,[e],"p0.url.href")},null,3,null),b("meta",null,{name:"viewport",content:"width=device-width, initial-scale=1.0"},null,3,null),b("link",null,{rel:"icon",type:"image/svg+xml",href:"/favicon.svg"},null,3,null),t.meta.map(n=>k("meta",{...n},null,0,n.key)),t.links.map(n=>k("link",{...n},null,0,n.key)),t.styles.map(n=>{var r;return k("style",{...n.props,...(r=n.props)!=null&&r.dangerouslySetInnerHTML?{}:{dangerouslySetInnerHTML:n.style}},null,0,n.key)}),t.scripts.map(n=>{var r;return k("script",{...n.props,...(r=n.props)!=null&&r.dangerouslySetInnerHTML?{}:{dangerouslySetInnerHTML:n.script}},null,0,n.key)})]},1,"wB_0")},dt=oe(ie(ut,"s_eRYm4bzoQ3o")),mt=()=>j(Se,{children:[b("head",null,null,[b("meta",null,{charset:"utf-8"},null,3,null),b("link",null,{rel:"manifest",href:"/manifest.json"},null,3,"0D_0"),b("link",null,{href:"https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap",rel:"stylesheet"},null,3,null),b("link",null,{href:"https://fonts.googleapis.com/css2?family=Orbitron:wght@400..900&display=swap",rel:"stylesheet"},null,3,null),b("link",null,{rel:"icon",type:"image/png",href:"./favicon.png"},null,3,null),j(dt,null,3,"0D_1")],1,null),b("body",null,{lang:"tr"},j(ke,null,3,"0D_2"),1,null)]},1,"0D_3"),ft=oe(ie(mt,"s_XSE0E99MgK8"));function yt(t){return st(j(ft,null,3,"KC_0"),{...t,containerAttributes:{lang:"en-us",...t.containerAttributes},serverData:{...t.serverData}})}export{yt as r,bt as s};
